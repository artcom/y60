#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <ft2build.h>
#pragma GCC visibility pop
