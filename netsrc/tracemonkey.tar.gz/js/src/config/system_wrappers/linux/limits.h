#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <linux/limits.h>
#pragma GCC visibility pop
