#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <errno.h>
#pragma GCC visibility pop
