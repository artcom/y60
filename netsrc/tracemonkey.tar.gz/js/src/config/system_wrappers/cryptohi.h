#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <cryptohi.h>
#pragma GCC visibility pop
