#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <gdk/gdkscreen.h>
#pragma GCC visibility pop
