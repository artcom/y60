#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <gdk/gdkkeysyms.h>
#pragma GCC visibility pop
