#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <gdk/gdkwindow.h>
#pragma GCC visibility pop
