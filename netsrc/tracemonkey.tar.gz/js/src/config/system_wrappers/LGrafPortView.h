#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <LGrafPortView.h>
#pragma GCC visibility pop
