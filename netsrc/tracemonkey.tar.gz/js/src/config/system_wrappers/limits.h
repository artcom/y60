#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <limits.h>
#pragma GCC visibility pop
