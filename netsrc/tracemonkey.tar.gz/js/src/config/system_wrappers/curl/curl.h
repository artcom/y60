#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <curl/curl.h>
#pragma GCC visibility pop
