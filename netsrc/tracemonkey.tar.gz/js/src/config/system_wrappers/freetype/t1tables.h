#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <freetype/t1tables.h>
#pragma GCC visibility pop
