#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <freetype/ftcache.h>
#pragma GCC visibility pop
