#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <Carbon.h>
#pragma GCC visibility pop
