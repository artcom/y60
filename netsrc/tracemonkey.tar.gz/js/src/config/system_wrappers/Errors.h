#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <Errors.h>
#pragma GCC visibility pop
