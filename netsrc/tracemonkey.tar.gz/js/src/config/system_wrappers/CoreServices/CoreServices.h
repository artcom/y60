#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <CoreServices/CoreServices.h>
#pragma GCC visibility pop
