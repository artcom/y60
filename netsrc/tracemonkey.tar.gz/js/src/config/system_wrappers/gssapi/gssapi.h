#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <gssapi/gssapi.h>
#pragma GCC visibility pop
