#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <gssapi/gssapi_generic.h>
#pragma GCC visibility pop
