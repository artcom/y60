#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <glib-object.h>
#pragma GCC visibility pop
