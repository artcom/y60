#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <descrip.h>
#pragma GCC visibility pop
