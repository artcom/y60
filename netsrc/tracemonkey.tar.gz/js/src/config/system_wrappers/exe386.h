#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <exe386.h>
#pragma GCC visibility pop
