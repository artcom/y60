#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <afxext.h>
#pragma GCC visibility pop
