#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <asm/sigcontext.h>
#pragma GCC visibility pop
