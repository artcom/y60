#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <iostream.h>
#pragma GCC visibility pop
