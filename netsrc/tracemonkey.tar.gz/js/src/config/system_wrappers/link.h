#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <link.h>
#pragma GCC visibility pop
