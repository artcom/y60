#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <app/Message.h>
#pragma GCC visibility pop
