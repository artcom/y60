#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <app/Cursor.h>
#pragma GCC visibility pop
