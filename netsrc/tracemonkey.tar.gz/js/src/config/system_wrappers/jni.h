#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <jni.h>
#pragma GCC visibility pop
