#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <CPString.cpp>
#pragma GCC visibility pop
