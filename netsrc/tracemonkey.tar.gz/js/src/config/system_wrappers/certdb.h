#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <certdb.h>
#pragma GCC visibility pop
