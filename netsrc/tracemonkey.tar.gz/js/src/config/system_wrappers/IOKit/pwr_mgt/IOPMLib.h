#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <IOKit/pwr_mgt/IOPMLib.h>
#pragma GCC visibility pop
