#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <IOKit/IOMessage.h>
#pragma GCC visibility pop
