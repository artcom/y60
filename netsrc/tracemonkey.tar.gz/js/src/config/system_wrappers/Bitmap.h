#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <Bitmap.h>
#pragma GCC visibility pop
