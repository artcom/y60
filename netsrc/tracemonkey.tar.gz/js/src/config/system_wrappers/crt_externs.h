#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <crt_externs.h>
#pragma GCC visibility pop
