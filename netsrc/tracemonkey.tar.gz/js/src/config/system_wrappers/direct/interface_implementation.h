#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <direct/interface_implementation.h>
#pragma GCC visibility pop
