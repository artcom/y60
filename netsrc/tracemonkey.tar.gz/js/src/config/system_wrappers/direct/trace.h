#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <direct/trace.h>
#pragma GCC visibility pop
