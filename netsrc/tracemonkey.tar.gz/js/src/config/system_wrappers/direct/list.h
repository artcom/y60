#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <direct/list.h>
#pragma GCC visibility pop
