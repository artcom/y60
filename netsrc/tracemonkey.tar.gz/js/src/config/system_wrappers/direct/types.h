#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <direct/types.h>
#pragma GCC visibility pop
