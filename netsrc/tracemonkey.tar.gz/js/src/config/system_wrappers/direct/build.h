#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <direct/build.h>
#pragma GCC visibility pop
