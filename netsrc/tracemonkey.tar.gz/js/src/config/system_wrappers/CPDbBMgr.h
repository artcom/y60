#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <CPDbBMgr.h>
#pragma GCC visibility pop
