#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <elf.h>
#pragma GCC visibility pop
