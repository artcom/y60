#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <LPeriodical.h>
#pragma GCC visibility pop
