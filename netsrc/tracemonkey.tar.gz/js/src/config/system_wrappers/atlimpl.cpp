#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <atlimpl.cpp>
#pragma GCC visibility pop
