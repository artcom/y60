#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <cairo-qpainter.h>
#pragma GCC visibility pop
