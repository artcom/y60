#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <afxcoll.h>
#pragma GCC visibility pop
