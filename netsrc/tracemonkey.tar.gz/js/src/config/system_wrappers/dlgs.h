#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <dlgs.h>
#pragma GCC visibility pop
