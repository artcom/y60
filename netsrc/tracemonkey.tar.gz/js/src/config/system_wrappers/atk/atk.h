#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <atk/atk.h>
#pragma GCC visibility pop
