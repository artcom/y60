#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <base/PCR_Base.h>
#pragma GCC visibility pop
