#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <Gestalt.h>
#pragma GCC visibility pop
