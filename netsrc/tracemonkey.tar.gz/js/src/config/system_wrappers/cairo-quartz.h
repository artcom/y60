#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <cairo-quartz.h>
#pragma GCC visibility pop
