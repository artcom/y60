#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <lber.h>
#pragma GCC visibility pop
