#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <locale.h>
#pragma GCC visibility pop
