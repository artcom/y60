#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <cairo-win32.h>
#pragma GCC visibility pop
