#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <fusion/reactor.h>
#pragma GCC visibility pop
