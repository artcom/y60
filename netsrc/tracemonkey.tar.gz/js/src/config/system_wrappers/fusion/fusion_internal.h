#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <fusion/fusion_internal.h>
#pragma GCC visibility pop
