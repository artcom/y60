#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <FSp_fopen.h>
#pragma GCC visibility pop
