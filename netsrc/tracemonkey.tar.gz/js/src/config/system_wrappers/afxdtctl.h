#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <afxdtctl.h>
#pragma GCC visibility pop
