#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <bsd/libc.h>
#pragma GCC visibility pop
