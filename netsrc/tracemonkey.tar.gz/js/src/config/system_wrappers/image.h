#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <image.h>
#pragma GCC visibility pop
