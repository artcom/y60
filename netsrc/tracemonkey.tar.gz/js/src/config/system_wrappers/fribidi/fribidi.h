#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <fribidi/fribidi.h>
#pragma GCC visibility pop
