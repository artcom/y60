#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <libgnomevfs/gnome-vfs-application-registry.h>
#pragma GCC visibility pop
