#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <LDialogBox.h>
#pragma GCC visibility pop
