#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <gtk/gtkimage.h>
#pragma GCC visibility pop
