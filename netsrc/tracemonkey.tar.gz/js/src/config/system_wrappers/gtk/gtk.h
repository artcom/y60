#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <gtk/gtk.h>
#pragma GCC visibility pop
