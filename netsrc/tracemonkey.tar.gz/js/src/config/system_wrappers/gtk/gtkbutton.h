#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <gtk/gtkbutton.h>
#pragma GCC visibility pop
