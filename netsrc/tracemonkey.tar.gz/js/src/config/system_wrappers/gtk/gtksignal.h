#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <gtk/gtksignal.h>
#pragma GCC visibility pop
