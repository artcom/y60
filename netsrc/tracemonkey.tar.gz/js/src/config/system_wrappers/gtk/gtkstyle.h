#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <gtk/gtkstyle.h>
#pragma GCC visibility pop
