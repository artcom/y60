#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <gtk/gtkvscrollbar.h>
#pragma GCC visibility pop
