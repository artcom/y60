#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <gtk/gtkprivate.h>
#pragma GCC visibility pop
