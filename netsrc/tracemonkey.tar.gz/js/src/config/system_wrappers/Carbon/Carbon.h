#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <Carbon/Carbon.h>
#pragma GCC visibility pop
