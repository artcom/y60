#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <atlhost.h>
#pragma GCC visibility pop
