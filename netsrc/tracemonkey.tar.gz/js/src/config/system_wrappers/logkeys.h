#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <logkeys.h>
#pragma GCC visibility pop
