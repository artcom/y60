#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <iodef.h>
#pragma GCC visibility pop
