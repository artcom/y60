#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <directfb_keyboard.h>
#pragma GCC visibility pop
