#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <libIDL/IDL.h>
#pragma GCC visibility pop
