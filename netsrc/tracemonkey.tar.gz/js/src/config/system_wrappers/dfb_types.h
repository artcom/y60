#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <dfb_types.h>
#pragma GCC visibility pop
