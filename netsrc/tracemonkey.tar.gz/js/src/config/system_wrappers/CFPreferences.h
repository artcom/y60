#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <CFPreferences.h>
#pragma GCC visibility pop
