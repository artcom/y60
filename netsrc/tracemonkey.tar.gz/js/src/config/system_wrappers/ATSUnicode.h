#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <ATSUnicode.h>
#pragma GCC visibility pop
