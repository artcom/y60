#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <dbus/dbus.h>
#pragma GCC visibility pop
