#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <dbus/dbus-glib-lowlevel.h>
#pragma GCC visibility pop
