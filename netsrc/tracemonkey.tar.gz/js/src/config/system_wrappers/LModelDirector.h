#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <LModelDirector.h>
#pragma GCC visibility pop
