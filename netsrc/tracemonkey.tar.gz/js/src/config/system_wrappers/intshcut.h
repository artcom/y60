#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <intshcut.h>
#pragma GCC visibility pop
