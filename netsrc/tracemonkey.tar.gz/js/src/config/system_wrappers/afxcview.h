#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <afxcview.h>
#pragma GCC visibility pop
