#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <libgnomeui/gnome-icon-lookup.h>
#pragma GCC visibility pop
