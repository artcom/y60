#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <libgnomeui/gnome-icon-theme.h>
#pragma GCC visibility pop
