#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <crypt.h>
#pragma GCC visibility pop
