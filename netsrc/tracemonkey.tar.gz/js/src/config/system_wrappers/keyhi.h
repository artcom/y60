#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <keyhi.h>
#pragma GCC visibility pop
