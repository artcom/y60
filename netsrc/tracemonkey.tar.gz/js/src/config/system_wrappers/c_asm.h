#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <c_asm.h>
#pragma GCC visibility pop
