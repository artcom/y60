#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <ifaddrs.h>
#pragma GCC visibility pop
