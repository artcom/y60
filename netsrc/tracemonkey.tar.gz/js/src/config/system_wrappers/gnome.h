#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <gnome.h>
#pragma GCC visibility pop
