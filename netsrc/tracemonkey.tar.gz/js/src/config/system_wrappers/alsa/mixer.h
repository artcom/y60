#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <alsa/mixer.h>
#pragma GCC visibility pop
