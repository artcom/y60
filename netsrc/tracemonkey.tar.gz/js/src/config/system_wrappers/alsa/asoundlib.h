#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <alsa/asoundlib.h>
#pragma GCC visibility pop
