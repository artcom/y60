#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <fabdef.h>
#pragma GCC visibility pop
