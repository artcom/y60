#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <cms.h>
#pragma GCC visibility pop
