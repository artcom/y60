#pragma GCC system_header
#pragma GCC visibility push(default)
#include_next <gmodule.h>
#pragma GCC visibility pop
